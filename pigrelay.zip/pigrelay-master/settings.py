# Must to set your controller IP here
CONTROLLER_IP = '192.168.2.179'

# Controller port is 51234 by default.
# If you want to change the port number
# you need to set the same port number in the controller application.
CONTROLLER_PORT = 51234

SOCKFILE = "/tmp/snort_alert"

BUFSIZE = 65863
